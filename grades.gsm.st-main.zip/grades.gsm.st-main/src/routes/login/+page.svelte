<div class="absolute center middle m l">
    <article>
        <h1>Sign on to grades.gsm.st</h1>
        <p>Sign on to grades.gsm.st to view your grades.</p>
        <form method="POST" action="?/login">
        <div class="field label border">
            <input type="text" name="username">
            <label>Username</label>
        </div>
        <div class="field label border">
            <input type="password" name="password">
            <label>Password</label>
        </div>
        <button class="small-round">Sign On</button>
    </form>
    </article>
</div>
<div class="s">
    <h1>Sign on to grades.gsm.st</h1>
    <p>Sign on to grades.gsm.st to view your grades.</p>
    <form method="POST" action="?/login">
    <div class="field label border">
        <input type="text" name="username">
        <label>Username</label>
    </div>
    <div class="field label border">
        <input type="password" name="password">
        <label>Password</label>
    </div>
    <button class="small-round">Sign On</button>
</form>
</div>